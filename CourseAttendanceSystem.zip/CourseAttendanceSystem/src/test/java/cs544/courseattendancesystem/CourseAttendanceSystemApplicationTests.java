package cs544.courseattendancesystem;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CourseAttendanceSystemApplicationTests {

    @Test
    void contextLoads() {
    }

}
