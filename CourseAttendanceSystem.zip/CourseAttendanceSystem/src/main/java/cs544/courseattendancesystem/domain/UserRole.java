package cs544.courseattendancesystem.domain;

public enum UserRole {ADMIN,STUDENT,SYS_ADMIN}