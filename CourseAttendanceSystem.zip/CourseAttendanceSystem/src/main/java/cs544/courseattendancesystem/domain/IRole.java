package cs544.courseattendancesystem.domain;

public interface IRole {
    public abstract String getRole();
}
