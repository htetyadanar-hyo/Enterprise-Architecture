package cs544.courseattendancesystem.domain;

public enum CourseOfferingType {
    ON_CAMPUS,DE
}
