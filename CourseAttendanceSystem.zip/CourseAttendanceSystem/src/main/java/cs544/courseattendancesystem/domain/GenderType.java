package cs544.courseattendancesystem.domain;

public enum GenderType {
    MALE,FEMALE
}
