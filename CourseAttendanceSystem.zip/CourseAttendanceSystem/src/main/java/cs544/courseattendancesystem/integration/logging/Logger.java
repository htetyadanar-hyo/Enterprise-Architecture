package cs544.courseattendancesystem.integration.logging;

public interface Logger {
}
