package cs544.courseattendancesystem.integration.logging;

public class LoggerImpl implements Logger{
}
