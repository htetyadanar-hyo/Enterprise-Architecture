package cs544.courseattendancesystem.service.dto;

import lombok.Data;

@Data
public class UserResponseDTO {
    private String username;
    private String token;
}
