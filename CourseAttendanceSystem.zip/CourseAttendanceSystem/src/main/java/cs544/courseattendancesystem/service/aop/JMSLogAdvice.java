package cs544.courseattendancesystem.service.aop;

public class JMSLogAdvice {
}
