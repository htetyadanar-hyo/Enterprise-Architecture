package cs544.courseattendancesystem.exception;

public class NotFoundException extends Exception{
    public NotFoundException(String message){super(message);}
}
