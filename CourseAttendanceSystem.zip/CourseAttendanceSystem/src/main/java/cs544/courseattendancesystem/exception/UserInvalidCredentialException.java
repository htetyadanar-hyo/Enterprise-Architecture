package cs544.courseattendancesystem.exception;

public class UserInvalidCredentialException extends Exception{
    public UserInvalidCredentialException(String message){super(message);}
}
