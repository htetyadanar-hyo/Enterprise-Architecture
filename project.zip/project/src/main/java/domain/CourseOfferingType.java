package domain;

public enum CourseOfferingType {
    DE,
    CAMPUS;
}
