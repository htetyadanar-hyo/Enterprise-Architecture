package domain;

public enum GenderType {
    MALE,
    FEMALE
}
